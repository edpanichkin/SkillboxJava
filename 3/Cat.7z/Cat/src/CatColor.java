public enum CatColor {
    BLACK,
    WHITE,
    RED,
    SMOKY,
    TRICOLOR
}
